# Clipteca

Guarda enlaces de video de tus redes sociales, organizados por categoría, con una vista previa grande al momento de añadirlos. Sin backend: todo vive en el `localStorage` del dispositivo.

## Qué incluye

- `index.html`, `styles.css`, `app.js` — la app.
- `manifest.json`, `sw.js` — la hacen instalable (PWA).
- `icons/` — íconos en 192px y 512px (normales y "maskable").

## Cómo funciona la vista previa

Al pegar un enlace, la app consulta la API pública y gratuita de [microlink.io](https://microlink.io) (sin necesidad de backend propio ni API key) para traer el título y la imagen grande del video. Si una red no permite extraer la imagen automáticamente (pasa a veces con Instagram), la app te deja pegar una URL de imagen a mano o guardar el enlace sin imagen.

> Nota: microlink.io tiene un límite gratuito de uso razonable por hora. Para un uso personal no deberías notarlo. Si más adelante quieres una fuente propia, se puede reemplazar la llamada en `fetchPreview()` dentro de `app.js`.

## 1. Publicar en GitHub Pages

1. Crea un repositorio nuevo en GitHub (puede ser público o privado con Pages habilitado en tu plan).
2. Sube estos archivos a la raíz del repo (o a una carpeta `/docs`, lo que prefieras).
3. Ve a **Settings → Pages**.
4. En "Build and deployment", elige **Deploy from a branch**, la rama `main` y la carpeta `/root` (o `/docs` si la usaste).
5. Guarda. En un par de minutos tu app estará en `https://tu-usuario.github.io/tu-repo/`.

Abre esa URL y prueba que todo cargue bien antes de seguir.

## 2. Convertir a APK con PWABuilder

1. Entra a [pwabuilder.com](https://www.pwabuilder.com).
2. Pega la URL de tu GitHub Pages y presiona **Start**.
3. PWABuilder va a leer tu `manifest.json` y tu service worker automáticamente. Deberías ver el ícono y el nombre "Clipteca" reconocidos.
4. Ve a la pestaña **Android** (o **Package for stores**) y genera el paquete.
5. Descarga el `.apk` (o `.aab` si vas a publicar en Google Play).

Si PWABuilder marca advertencias sobre el service worker o el manifest, revisa que la URL publicada sirva `manifest.json` y `sw.js` desde la raíz del sitio (rutas relativas, como ya están configuradas aquí).

## Personalización rápida

- **Colores de categorías**: la paleta está en la constante `PALETTE` al inicio de `app.js`.
- **Categoría inicial**: se crea "General" la primera vez que se abre la app; se puede cambiar en `loadState()`.
- **Ícono de la app**: regenera los PNG en `icons/` si quieres otro diseño (deben mantenerse los tamaños 192 y 512, normal y maskable).
